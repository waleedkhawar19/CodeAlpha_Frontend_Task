// small interactive bits: mobile toggle, smooth scroll, demo contact submit
document.addEventListener('DOMContentLoaded', () => {
  const nav = document.getElementById('nav');
  const navToggle = document.getElementById('navToggle');
  const year = document.getElementById('year');
  year.textContent = new Date().getFullYear();

  navToggle.addEventListener('click', () => {
    nav.classList.toggle('open');
  });

  // Smooth scroll for internal links
  document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click', e=>{
      const target = document.querySelector(a.getAttribute('href'));
      if(target){
        e.preventDefault();
        target.scrollIntoView({behavior:'smooth', block:'start'});
        if(nav.classList.contains('open')) nav.classList.remove('open');
      }
    });
  });

  // Demo form submit
  const form = document.getElementById('contactForm');
  if(form){
    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      // simple local success UI
      alert('Thanks! Your message was sent (demo). I will reply soon.');
      form.reset();
    });
  }
});
